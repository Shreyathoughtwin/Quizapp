
import React from 'react';
import Model from 'react-model';
import './Quiz.css';


class QuizApp extends React.Component {
  constructor(props) {
    super(props);


    this.state = {

    questions: [

    {
    question: 'Which of the following is used in React.js to increase performance?',
     options: ['a. Virtual DOM', 'b. Original DOM', 'c. Both A and B', 'd. None of the above'],
    answer: 'a. Virtual DOM',

      },

    {
       question: 'Which of the following acts as the input of a class-based component?',
       options: ['a. Class', 'b. Factory', 'c. Render', 'd. Props'],
        answer: 'd. Props',
},


      {

         question: 'Which of the following keyword is used to create a class inheritance?',
        options: ['a. Create', 'b. Inherits', 'c. Extends', 'd. This'],
       answer: 'c. Extends',
    },


   {
      question: 'A class is a type of function, but instead of using the keyword function to initiate it, which keyword do we use?',
         options: ['a. Constructor', 'b. Class', 'c. Object', 'd. DataObject'],
        answer: 'b. Class',
},

     {
         question: 'What is the default port where webpack-server runs?',
        options: ['a. 3000', 'b. 8080', 'c. 3030', 'd. 6060'],
         answer: 'b. 8080',
    },

    {
         question: 'How many numbers of elements a valid react component can return?',
         options: ['a. 1', 'b. 2', 'c. 4', 'd. 5'],
         answer: 'a. 1',
   },


   {
          question: 'What are the two ways to handle data in React?',
          options: ['a. State & Props', 'b. Services & Components', 'c. State & Services', 'd. State & Component'],
   answer: 'a. State & Props',
   },


        {
         
          question: 'Does React.js create a VIRTUAL DOM in the memory?',
          options: ['a. TRUE', 'b. FALSE', 'c. Can be true or false', 'd. Cannot say'],
          answer: 'a. TRUE',
     },

    {
          question: 'Which of the following is used to pass data to a component from outside in React.js?',
           options: ['a. SetState', 'b. Render with arguments', 'c. Props', 'd. PropTypes'],
          answer: 'c. Props',
   },

        {
          question: 'Which of the following function is used to change the state of the React.js component?',
          options: ['a. this.setState', 'b. this.setChangeState', 'c. this.State{}', 'd. None of the above.'],
           answer: 'a. this.setState',
   },

  ],

      currentIndex: 0,
      selectedOption: '',
      answers: [],
      score: 0,
        showscore: false,
         timeLeft: 60,
          //  QuizComplete:false,

};
       this.timer = null;

  }

        componentDidMount() {
       this.startTimer();

 }


     startTimer = () => {
        this.timer = setInterval(() => {

    this.setState((prevState) => {
      if (prevState.timeLeft > 0) {
            return { timeLeft: prevState.timeLeft - 1 };

         } else {

        this.nextQuestion();
          return { timeLeft: 60 };

}

});

}, 1000);
  };


        handleOptionChange = (e) => {
            this.setState({ selectedOption: e.target.value });

  };


         nextQuestion = () => {

    const { currentIndex, questions, selectedOption, answers } = this.state;
    
    if (selectedOption) {
           const Correct = selectedOption === questions[currentIndex].answer;
      answers.push(Correct);

}


      clearInterval(this.timer);
        if (currentIndex < questions.length - 1) {

      this.setState({ currentIndex: currentIndex + 1, selectedOption: '', timeLeft: 60 }, this.startTimer);
     
         } else {
     
      this.showFinalscore();
 }};


     showFinalscore = () => {

    clearInterval(this.timer);

      const score = this.state.answers.filter((answer) => answer).length;
       this.setState({ score, showscore: true });

  };


       resetquiz = () => {
       this.setState(

      {
        currentIndex: 0,
          selectedOption: '',
        answers: [],
        score: 0,
        showscore: false,
        timeLeft: 60,
  },

        this.startTimer
  );
  };


       handleCancel = () => {

     clearInterval(this.timer);
    this.setState({

      currentIndex: 0,
      selectedOption: '',
      answers: [],
      score: 0,
      showscore: false,
      timeLeft: 60,


  });

       
  alert('Thank you for taking the quiz');

};

  render() {

    const { questions, currentIndex, selectedOption, showscore, score, timeLeft } = this.state;

    const { username } = this.props;

         if (showscore) {
      return (

                    <div>

          <h3>Quiz Completed</h3>
       <p style={{ color: score > 6 ? 'green' : 'red' }}>Your score: {score}/{questions.length}</p>
          
          <p>Username: {username}</p>

       <button onClick={this.resetquiz}>Try Again</button>
     <button onClick={this.handleCancel}>Cancel</button>

 </div>
    // );
// this.setState({QuizComplete:true})
//        alert('Quiz completed, thank you!');
  );


 }

 // submitQuiz =()=>{
//   clearInterval(this.timer);

// alert('Quiz submitted Succefully');

    const currentQuestion = questions[currentIndex];
    const userArrayList = JSON.parse(localStorage.getItem('userList')) || [];

    return (

     <div>

        <h3>QuizApp</h3>
      <h5>{userArrayList.username}</h5>

   <p>Time left: {timeLeft}s</p>

    <p>Question {currentIndex + 1} / {questions.length}</p>

     <p>{currentQuestion.question}</p>

  {currentQuestion.options.map((option, index) => (
          <label key={index}>

            <input type="radio" value={option} checked={selectedOption === option}onChange={this.handleOptionChange}/>{option}
          </label>

 ))}
        <br /><br /><br />

        {currentIndex < questions.length - 1 ? (
          <button onClick={this.nextQuestion}>Next</button>

          
 ) : (
          <button onClick={this.showFinalscore}>Submit</button>
 )}
        <br /><br></br>

        <button onClick={this.handleCancel}>Cancel</button>
        </div>

)


}
}
export default QuizApp;