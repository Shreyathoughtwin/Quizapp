
import React from 'react';
 import Model from 'react-model';
import './Loginpage.css';
// import QuizApp from './Quiz/QuizApp'


class Login extends React.Component {

    constructor(props) {
        super(props);

        const userArrayList = JSON.parse(localStorage.getItem('userList')) || [];

        this.state = {
            username: "",
            password: "",
            userArrayList: userArrayList,
            Loggedinuser:null,
            showmodel:false,
            // Loggedinuser:"false"
        }

    }

       handleChange=(e) => {
        const { name, value } = e.target;
             this.setState({
         [name]: value
      });
};

        handleSubmit = (e) => {

         e.preventDefault();
        const { username, password, userArrayList } = this.state;

          const storedUser = userArrayList.find(user => user.username === username && user.password === password);

            if (storedUser) {
            alert('Login successful');
            this.setState({loggedinuser:username,showmodel:true},()=>{
                this.props.Login(username);
            })

} else {
              alert('Invalid username or password');
}

};
   
     closemodel=()=>{
        this.setState({showmodel:false});
     }

 render() {


    const{loggedinuser,showmodel}=this.state;
return (
               <div>
                <h2>Login</h2>

                <form onSubmit={this.handleSubmit}>

                    <div>
                    <label>Username:</label>
                    <input type="text" name="username" value={this.state.username} onChange={this.handleChange} />

            </div>
                    <div>
                        <label>Password:</label>
                          <input type="password" name="password" value={this.state.password} onChange={this.handleChange} />
                    </div>

<br></br>
                 <button type="submit">Login</button>
                </form>


           <model open={showmodel}close={this.closemodel} contentlabel="Login successful">

             <h1>Welcome {loggedinuser}</h1> 

            <button onClick={this.closemodel}>close</button>
           </model>
 </div>
    );
}
    
}
export default Login;