function user(){
    return(
        <h1>user Components</h1>
    )
}

export default user;